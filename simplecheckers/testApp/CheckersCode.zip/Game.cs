﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MainGame
{
	public partial class Game : Form
	{
		public Game()
		{
			InitializeComponent();
		}

		private void btnExit_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void btnReset_Click(object sender, EventArgs e)
		{
			cb.Reset();
			statusMessage.Text = "Game reset successfully";
		}

		private void btnStart_Click(object sender, EventArgs e)
		{
			if (String.IsNullOrEmpty(tbxName.Text))
			{
				MessageBox.Show("Please enter a name for your player", "Missing Name", MessageBoxButtons.OK);
				return;
			}

			if (!rbxAlphaBeta.Checked && !rbxMinMax.Checked)
			{
				MessageBox.Show("Please choose one of the algorithms", "Missing Algorithm", MessageBoxButtons.OK);
				return;
			}

			lblPlayerName.Text = tbxName.Text;

			if (rbxMinMax.Checked)
			{
				lblPlaying.Text += " Min-Max algorithm";
			}
			else
			{
				lblPlaying.Text += " Alpha-Beta algorithm";
			}
			
			loginPanel.Visible = false;
			btnReset.Visible = true;
			cb.Enabled = true;

			cb.Reset();
		}
	}
}
