﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MainGame
{
	public partial class CheckersBoard : Panel
	{
		#region Members

		public static int size = 8;	// Size of board (for example, if 8 the board will be 8x8 cells
		private Pen penBlack = new Pen(Color.FromArgb(255, 0, 0, 0));
		private Pen penWhite = new Pen(Color.FromArgb(255, 1, 1, 1));
		private Brush brushBlack = Brushes.SaddleBrown;
		private CheckersPiece[,] cmArray = new CheckersPiece[8, 8];
		private int cellSize;
		private CheckersElements nowPlaying;
		private CheckersElements human = CheckersElements.Red;
		private CheckersElements ai = CheckersElements.Black;
		private int RedCount = 12;
		private int BlackCount = 12;

		#endregion Members

		#region Public Properties

		public CheckersElements NowPlaying
		{
			get
			{
				return nowPlaying;
			}
			set
			{
				nowPlaying = value;
			}
		}

		public CheckersElements Human
		{
			get
			{
				return human;
			}
		}

		public CheckersElements AI
		{
			get
			{
				return ai;
			}
		}

		#endregion Public Properties

		#region Private Methods

		/// <summary>
		/// Initializes the array that represents the array of chess elements
		/// on the board.
		/// </summary>
		private void InitializeElementsArray()
		{
			// Populating checkers board
			for (int i = 0; i < size; ++i)
			{
				for (int j = 0; j < size; ++j)
				{
					if ((i + j) % 2 == 1)
					{
						if (j < 3)
						{
							// If we're looking at the upper side of the board
							cmArray[i, j] = new CheckersPiece(CheckersElements.Black, new Point(i, j), this);
						}
						else if (j > 4)
						{
							// If we're looking at the bottom side of the board
							cmArray[i, j] = new CheckersPiece(CheckersElements.Red, new Point(i, j), this);
						}
						else
						{
							cmArray[i, j] = new CheckersPiece(CheckersElements.Null, new Point(i, j), this);
							cmArray[i, j].Visible = false;
						}
					}
					else
					{
						cmArray[i, j] = null; // White cell, will never be used
					}
				}
			}

			cellSize = this.Width / size;
		}

		#endregion Private Methods

		#region Public Methods

		public CheckersBoard()
		{
			InitializeComponent();
			InitializeElementsArray();
		}

		/// <summary>
		/// Resets the board for a new game
		/// </summary>
		public void Reset()
		{
			DrawPiecesOnBoard();
		}

		/// <summary>
		/// Updates the array with a movement of a checkers piece
		/// </summary>
		/// <param name="from"></param>
		/// <param name="to"></param>
		public void UpdateMovement(Point from, Point to)
		{
			if (cmArray[to.X, to.Y].Type != CheckersElements.Null)
			{
				return;
			}

			CheckersPiece p = cmArray[from.X, from.Y];
			CheckersPiece nullObject = new CheckersPiece(CheckersElements.Null, from, this);

			cmArray[to.X, to.Y] = p;
			cmArray[from.X, from.Y] = nullObject;

		}

		/// <summary>
		/// Draws the checkers pieces on the board (Updates its location and sets alive status to true)
		/// </summary>
		private void DrawPiecesOnBoard()
		{
			foreach (CheckersPiece p in Controls)
			{
				p.Location = GetBoardCoordinates(p.BoardLocation);
				p.IsAlive = true;
				p.Visible = true;
				p.BringToFront();
			}
		}

		/// <summary>
		/// Changes the active player to the other one
		/// </summary>
		/// <param name="changeFrom"></param>
		public void ChangePlayer(CheckersElements changeFrom)
		{
			UpdateLabels();

			if (changeFrom == CheckersElements.Black)
			{
				nowPlaying = CheckersElements.Red;
			}
			else
			{
				nowPlaying = CheckersElements.Black;
			}
		}

		public void UpdateLabels()
		{
			// Implement all the label updates here
		}

		/// <summary>
		/// Updates the pieces locations on the board
		/// </summary>
		public void UpdatePieces()
		{
		}

		public Point GetBoardCoordinates(int x, int y)
		{
			return new Point(x * (this.Width / size), y * (this.Width / size));
		}

		public Point GetBoardCoordinates(Point p)
		{
			return GetBoardCoordinates(p.X, p.Y);
		}

		public Point GetArrayCoordinates(int x, int y)
		{
			return new Point(x / (this.Width / size), y / (this.Width / size));
		}

		public Point GetArrayCoordinates(Point p)
		{
			return GetArrayCoordinates(p.X, p.Y);
		}

		/// <summary>
		/// Draws the chess board on the form
		/// </summary>
		/// <param name="pe">Paint event arguments</param>
		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}

		/// <summary>
		/// Checks to see if a move is possible.
		/// </summary>
		/// <param name="start">Starting point (in board coordinates)</param>
		/// <param name="end">Ending point (in board coordinates)</param>
		/// <returns>Boolean</returns>
		public bool MovePossible(Point start, Point end)
		{
			// If we're trying to move the piece to a white (null) cell - return false
			if (cmArray[end.X, end.Y] == null)
			{
				return false;
			}

			if ((start.X == end.X) && (start.Y == end.Y))
			{
				return false;
			}
			else if (cmArray[start.X, start.Y].IsKing && (Math.Abs(start.X - end.X) == 1) && (Math.Abs(start.Y - end.Y) == 1))
			{

				return true;
			}
			else if ((cmArray[end.X, end.Y].Type == CheckersElements.Null)
				   && (Math.Abs(start.X - end.X) == 1) && (start.Y - end.Y == -1))
			{
				return true;
			}
			else if ((cmArray[end.X, end.Y].Type == CheckersElements.Null) &&
				(Math.Abs(start.X - end.X) == 2) && (Math.Abs(start.Y - end.Y) == 2) &&
				(cmArray[(start.X + end.X) / 2, (start.Y + end.Y) / 2] != null) &&
				(cmArray[(start.X + end.X) / 2, (start.Y + end.Y) / 2].Type != CheckersElements.Null))
			{
				// If we're eating an opponent
				cmArray[(start.X + end.X) / 2, (start.Y + end.Y) / 2].Visible = false;

				if (cmArray[(start.X + end.X) / 2, (start.Y + end.Y) / 2].Type == CheckersElements.Black)
				{
					BlackCount--;
				}
				else
				{
					RedCount--;
				}

				return true;
			}
			else
			{
				// If move is impossible
				return false;
			}


		}

		/// <summary>
		/// Aligns the piece (panel) to the right cell location on the board
		/// </summary>
		/// <param name="p"></param>
		/// <returns></returns>
		public Point AlignToCells(Point p)
		{
			int x = 0;
			int y = 0;

			for (int i = 0; i < size; i++)
			{
				if (p.X > x && (p.X - x > cellSize))
				{
					x += cellSize;
				}
				else
				{
					break;
				}
			}

			for (int i = 0; i < size; i++)
			{
				if (p.Y > y && (p.Y - y > cellSize))
				{
					y += cellSize;
				}
				else
				{
					break;
				}
			}

			return new Point(x, y);
		}

		#endregion Public Methods
	}
}
