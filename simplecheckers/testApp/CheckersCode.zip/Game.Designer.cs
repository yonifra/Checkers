﻿namespace MainGame
{
	partial class Game
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.btnReset = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.gbStats = new System.Windows.Forms.GroupBox();
			this.lblVS = new System.Windows.Forms.Label();
			this.lblPlaying = new System.Windows.Forms.Label();
			this.lblPlayerName = new System.Windows.Forms.Label();
			this.loginPanel = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.rbxAlphaBeta = new System.Windows.Forms.RadioButton();
			this.rbxMinMax = new System.Windows.Forms.RadioButton();
			this.lblChoose = new System.Windows.Forms.Label();
			this.btnStart = new System.Windows.Forms.Button();
			this.lblName = new System.Windows.Forms.Label();
			this.tbxName = new System.Windows.Forms.TextBox();
			this.btnExit = new System.Windows.Forms.Button();
			this.statusStrip = new System.Windows.Forms.StatusStrip();
			this.statusMessage = new System.Windows.Forms.ToolStripStatusLabel();
			this.tooltip = new System.Windows.Forms.ToolTip(this.components);
			this.cb = new MainGame.CheckersBoard();
			this.groupBox1.SuspendLayout();
			this.gbStats.SuspendLayout();
			this.loginPanel.SuspendLayout();
			this.panel1.SuspendLayout();
			this.statusStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnReset
			// 
			this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnReset.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnReset.Location = new System.Drawing.Point(15, 502);
			this.btnReset.Name = "btnReset";
			this.btnReset.Size = new System.Drawing.Size(121, 32);
			this.btnReset.TabIndex = 0;
			this.btnReset.Text = "Reset Game";
			this.tooltip.SetToolTip(this.btnReset, "Starts a new game");
			this.btnReset.UseVisualStyleBackColor = true;
			this.btnReset.Visible = false;
			this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.gbStats);
			this.groupBox1.Controls.Add(this.btnExit);
			this.groupBox1.Controls.Add(this.btnReset);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
			this.groupBox1.Location = new System.Drawing.Point(565, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(148, 586);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Control Panel";
			// 
			// gbStats
			// 
			this.gbStats.Controls.Add(this.lblVS);
			this.gbStats.Controls.Add(this.lblPlaying);
			this.gbStats.Controls.Add(this.lblPlayerName);
			this.gbStats.Controls.Add(this.loginPanel);
			this.gbStats.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
			this.gbStats.Location = new System.Drawing.Point(7, 20);
			this.gbStats.Name = "gbStats";
			this.gbStats.Size = new System.Drawing.Size(135, 476);
			this.gbStats.TabIndex = 2;
			this.gbStats.TabStop = false;
			this.gbStats.Text = "Your Stats";
			// 
			// lblVS
			// 
			this.lblVS.AutoSize = true;
			this.lblVS.Location = new System.Drawing.Point(46, 49);
			this.lblVS.Name = "lblVS";
			this.lblVS.Size = new System.Drawing.Size(27, 19);
			this.lblVS.TabIndex = 2;
			this.lblVS.Text = "vs.";
			this.lblVS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblVS.Visible = false;
			// 
			// lblPlaying
			// 
			this.lblPlaying.AutoSize = true;
			this.lblPlaying.Location = new System.Drawing.Point(60, 78);
			this.lblPlaying.Name = "lblPlaying";
			this.lblPlaying.Size = new System.Drawing.Size(0, 19);
			this.lblPlaying.TabIndex = 1;
			this.lblPlaying.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPlayerName
			// 
			this.lblPlayerName.AutoSize = true;
			this.lblPlayerName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPlayerName.Location = new System.Drawing.Point(60, 21);
			this.lblPlayerName.Name = "lblPlayerName";
			this.lblPlayerName.Size = new System.Drawing.Size(0, 19);
			this.lblPlayerName.TabIndex = 0;
			this.lblPlayerName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// loginPanel
			// 
			this.loginPanel.Controls.Add(this.panel1);
			this.loginPanel.Controls.Add(this.btnStart);
			this.loginPanel.Controls.Add(this.lblName);
			this.loginPanel.Controls.Add(this.tbxName);
			this.loginPanel.Location = new System.Drawing.Point(1, 21);
			this.loginPanel.Name = "loginPanel";
			this.loginPanel.Size = new System.Drawing.Size(140, 193);
			this.loginPanel.TabIndex = 5;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.rbxAlphaBeta);
			this.panel1.Controls.Add(this.rbxMinMax);
			this.panel1.Controls.Add(this.lblChoose);
			this.panel1.Location = new System.Drawing.Point(0, 51);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(140, 72);
			this.panel1.TabIndex = 5;
			// 
			// rbxAlphaBeta
			// 
			this.rbxAlphaBeta.AutoSize = true;
			this.rbxAlphaBeta.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
			this.rbxAlphaBeta.Location = new System.Drawing.Point(12, 46);
			this.rbxAlphaBeta.Name = "rbxAlphaBeta";
			this.rbxAlphaBeta.Size = new System.Drawing.Size(91, 21);
			this.rbxAlphaBeta.TabIndex = 6;
			this.rbxAlphaBeta.TabStop = true;
			this.rbxAlphaBeta.Text = "Alpha-Beta";
			this.rbxAlphaBeta.UseVisualStyleBackColor = true;
			// 
			// rbxMinMax
			// 
			this.rbxMinMax.AutoSize = true;
			this.rbxMinMax.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Bold);
			this.rbxMinMax.Location = new System.Drawing.Point(12, 22);
			this.rbxMinMax.Name = "rbxMinMax";
			this.rbxMinMax.Size = new System.Drawing.Size(78, 21);
			this.rbxMinMax.TabIndex = 5;
			this.rbxMinMax.TabStop = true;
			this.rbxMinMax.Text = "Min-Max";
			this.rbxMinMax.UseVisualStyleBackColor = true;
			// 
			// lblChoose
			// 
			this.lblChoose.AutoSize = true;
			this.lblChoose.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblChoose.Location = new System.Drawing.Point(3, 0);
			this.lblChoose.Name = "lblChoose";
			this.lblChoose.Size = new System.Drawing.Size(123, 18);
			this.lblChoose.TabIndex = 4;
			this.lblChoose.Text = "Choose Algorithm:";
			// 
			// btnStart
			// 
			this.btnStart.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnStart.Location = new System.Drawing.Point(5, 129);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(128, 31);
			this.btnStart.TabIndex = 2;
			this.btnStart.Text = "Start Game!";
			this.tooltip.SetToolTip(this.btnStart, "Click to start game");
			this.btnStart.UseVisualStyleBackColor = true;
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// lblName
			// 
			this.lblName.AutoSize = true;
			this.lblName.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblName.Location = new System.Drawing.Point(3, 0);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(81, 18);
			this.lblName.TabIndex = 3;
			this.lblName.Text = "Your Name:";
			// 
			// tbxName
			// 
			this.tbxName.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tbxName.Location = new System.Drawing.Point(2, 21);
			this.tbxName.Name = "tbxName";
			this.tbxName.Size = new System.Drawing.Size(135, 23);
			this.tbxName.TabIndex = 4;
			// 
			// btnExit
			// 
			this.btnExit.Font = new System.Drawing.Font("Calibri", 12F);
			this.btnExit.Image = global::MainGame.Properties.Resources.cancel;
			this.btnExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btnExit.Location = new System.Drawing.Point(15, 538);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(121, 42);
			this.btnExit.TabIndex = 1;
			this.btnExit.Text = "Exit Game";
			this.btnExit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.tooltip.SetToolTip(this.btnExit, "Exit Checkers");
			this.btnExit.UseVisualStyleBackColor = true;
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// statusStrip
			// 
			this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusMessage});
			this.statusStrip.Location = new System.Drawing.Point(0, 564);
			this.statusStrip.Name = "statusStrip";
			this.statusStrip.Size = new System.Drawing.Size(565, 22);
			this.statusStrip.TabIndex = 3;
			this.statusStrip.Text = "statusStrip1";
			// 
			// statusMessage
			// 
			this.statusMessage.Name = "statusMessage";
			this.statusMessage.Size = new System.Drawing.Size(38, 17);
			this.statusMessage.Text = "Ready";
			// 
			// cb
			// 
			this.cb.BackColor = System.Drawing.Color.White;
			this.cb.BackgroundImage = global::MainGame.Properties.Resources.checkers;
			this.cb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.cb.Enabled = false;
			this.cb.Location = new System.Drawing.Point(0, 0);
			this.cb.Name = "cb";
			this.cb.NowPlaying = MainGame.CheckersElements.Black;
			this.cb.Size = new System.Drawing.Size(560, 560);
			this.cb.TabIndex = 2;
			// 
			// Game
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(713, 586);
			this.Controls.Add(this.statusStrip);
			this.Controls.Add(this.cb);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "Game";
			this.Text = "Checkers Game - V0.2 ALPHA - Nov. 24, 2010";
			this.groupBox1.ResumeLayout(false);
			this.gbStats.ResumeLayout(false);
			this.gbStats.PerformLayout();
			this.loginPanel.ResumeLayout(false);
			this.loginPanel.PerformLayout();
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.statusStrip.ResumeLayout(false);
			this.statusStrip.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnReset;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnExit;
		private CheckersBoard cb;
		private System.Windows.Forms.StatusStrip statusStrip;
		private System.Windows.Forms.ToolStripStatusLabel statusMessage;
		private System.Windows.Forms.Label lblName;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.TextBox tbxName;
		private System.Windows.Forms.Panel loginPanel;
		private System.Windows.Forms.GroupBox gbStats;
		private System.Windows.Forms.Label lblPlayerName;
		private System.Windows.Forms.Label lblPlaying;
		private System.Windows.Forms.ToolTip tooltip;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label lblChoose;
		private System.Windows.Forms.RadioButton rbxAlphaBeta;
		private System.Windows.Forms.RadioButton rbxMinMax;
		private System.Windows.Forms.Label lblVS;
	}
}

